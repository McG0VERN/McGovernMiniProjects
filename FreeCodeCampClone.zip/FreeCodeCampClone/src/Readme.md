#<strong> FreeCodeCampClone</strong>

<p>Clone of the section "What our alumi say about us", using React.</p>

🔎 Learn Skills: 
* Basic Concepts of React (Components, props, hooks)
![](imagenes/Captura.JPG)
